﻿namespace TravelInEgyptix.Fundamentals;

public class SOSEgyptians 
{
    public static string CleoCode(string toEncode, int key)
   {
       if (key < 0)
           throw new ArgumentException(""); // ethe main throw argument kita 

       int jw = 2 * key;  char[] lv = new char[toEncode.Length]; // ethe main int teh char kita fir main new char kita 
       
       for (int a = 0; a < toEncode.Length; a++) // ethe main bcle for kiti 
       {
           char v = toEncode[a]; 
           if (v >= 'A' && v <= 'Z')
               lv[a] = (char)((v - 'A' + jw) % 26 + 'A');else if (v >= 'a' && v <= 'z') lv[a] = (char)((v - 'a' + jw) % 26 + 'a');else
               lv[a] = v; // ethe har majuscule nu vekhda
           
       } return new string(lv); // ethe main rt new string kita 
   }
    
   public static int RomanFormations(char c, int level)
   {
       if (level < 0)
           throw new ArgumentException(""); // ethe main throw argmt kita 
       int p = 0; // ethe main int kita 
       if (c == 's') p = level * 1; // ethe main p nu level multiply kita 
       else if (c == 't') p = level * 10; 
       else if (c == 'e') //eht main c nu e kita 
           for (int s = 1; s <= level; s++)  // ethe main bcl kita 
               p += 2 * s - 1;
       else if (c == 'c')
           for (int s = 1; s <= level; s++) // ethe main for kita 
               p += 6 * s; // ethe main p nu change kita  
       else
           throw new ArgumentException(""); // ethe main thrw argm kita 
       return p; // ethe main rt it 
   }


   public static void Pyramids(int n, char x, string pathname)
   {
       if (n < 0)
           throw new ArgumentException(""); // ethe main throw argument kita 

       try
       { using (StreamWriter e= new StreamWriter(pathname))
           
           for (int j= 1;j<= n; j++) // ethe main blc for kita 
               {
                   int a= n - j; int s = 2 * j- 1; // ethe main int kita 
                   string line = new string(' ', a)+new string(x, s) + new string(' ', a); e.WriteLine(line); // ethe main write line kita 
               } }
       catch (Exception) // ethe main catch kita 
       { throw new ArgumentException(""); } // ethe main throw agm kita 
   }
}

