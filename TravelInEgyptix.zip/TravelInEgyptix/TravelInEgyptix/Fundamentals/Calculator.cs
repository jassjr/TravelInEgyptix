﻿namespace TravelInEgyptix.Fundamentals;

public class Calculator
{ public static double Calculate(char c, double a, double b)
    {
        double m = 0;  // ethe main double kita 
        if (c == '+' || c == '-' || c == '*' || c == '/' || c == '^' || c == 'e' || c == 'l')
        {
            if (c == '+') m = a + b; // ethe main if klita 
            else if (c == '-') m = a - b;
            else if (c == '*') m = a * b;
            else if (c == '/')
            {
                if (b == 0)
                    throw new ArgumentException(""); m = a / b;  // ethe main thrw argt kita 
            }
            else if (c == '^') // ethe main else if kita
            { if (b < 0)
                    throw new ArgumentException(""); m = Math.Pow(a, b);// ethe main thrw argt kita fir math pw kita 
            }
            else if (c == 'e') { m = Math.Exp(a); } // ethe main thrw argt kita fir math exp kita 
            else if (c == 'l')
            {
                if (a <= 0) throw new ArgumentException(""); m = Math.Log(a);// ethe main thrw argt kita fir math lg kita 
            }
        }
        else throw new ArgumentException(""); // ethe main trw arg kita 
        return m; // ethe main rt it 
    }
}
