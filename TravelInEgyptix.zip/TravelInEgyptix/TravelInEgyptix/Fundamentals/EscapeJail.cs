﻿namespace TravelInEgyptix.Fundamentals;

public class EscapeJail
{
    public static bool MovingCat(string moves, int x1, int y1, int x2, int y2)
    {
        int m = x1; int n = y1; // ethe main int kita 
        foreach (char ve in moves)
        { 
            if (ve == 'z') n += 1; // ethe main if kita 
            
            else if (ve == 'q') m -= 1; // ethe main if else kita 
            
            else if (ve == 's') n -= 1;// ethe main if else kita 
            
            else if (ve == 'd') m += 1;// ethe main if else kita 
            
            else throw new ArgumentException(""); // ethe main thw arg kita 
            
        } return m == x2 && n == y2; // rt it 
    }
}