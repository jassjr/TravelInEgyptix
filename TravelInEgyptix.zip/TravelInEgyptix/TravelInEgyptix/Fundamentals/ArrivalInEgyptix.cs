﻿namespace TravelInEgyptix.Fundamentals;



// function Quatrobonnacius 
public class ArrivalInEgyptix
{ 
    // Fonction Quatrobonnaccius
    public static long Quatrobonnaccius(int n) 
    {
        if (n < 0) 
        {
            throw new ArgumentException("E: negative"); // print error 
        }
        if (n == 0) 
        {
            return 0; // return zero
        }
        if (n == 1 || n == 2) 
        {
            return 1; // return one
        }
        if (n == 3) 
        {
            return 2; // return two
        }
        long t0 = 0; // init
        long t1 = 1; // init
        long t2 = 1; // init
        long t3 = 2; // init 
        long tn = 0; // init

        int a = 4; // init
        while (a <= n) 
        {
            tn = t0 + t1 + t2 + t3; // addtn
            t0 = t1; // set1
            t1 = t2; // set2
            t2 = t3; // set3
            t3 = tn; // set it 
            a++; // incrementation
        }
        return tn; // return
    }
    
    // Fonction ArchimedusNumber
    public static double ArchimedusNumber(int n)
    {
        if (n < 0)
        {
            throw new ArgumentException("Error: negative"); // print error 
        }

        double a = 0.0; // init a
        int b = 1; // init b
        int x = 0; // init x
        while (x <= n)
        {
            a += b * (1.0 / (2 * x + 1)); // calc
            b *= -1; // altrn val
            x++; // incrementation
        }
        a *= 4; // mult it
        return a; // return 
    }
    
    // Fonction Atoi
    public static int Atoi(string pathname)
    {
        if (!File.Exists(pathname))
        {
            throw new ArgumentException("Error: not exist"); // error 
        }

        string? stg; // declr
        using (StreamReader st = new StreamReader(pathname))
        {
            stg = st.ReadLine();
        }
        if (string.IsNullOrEmpty(stg))
        {
            throw new ArgumentException("Error: not exist"); // error
        }
        if (!Lma(stg))
        {
            throw new ArgumentException("Error: not exist"); // error
        }
        return int.Parse(stg); // return 
    }
    
    // Fonction Lma
    private static bool Lma(string s)
    {
        int a = 0; // init
        if (s[0] == '-') 
        {
            a = 1; // set it
        }

        int x = a; // init
        while (x < s.Length)
        {
            if (!char.IsDigit(s[x]))
            {
                return false; // false
            }
            x++; // incrementation
        }
        return true; // true 
    }
}
 
 
 