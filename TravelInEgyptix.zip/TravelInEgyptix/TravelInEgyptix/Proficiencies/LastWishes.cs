﻿namespace TravelInEgyptix.Proficiencies;

public class LastWishes
{ 
    public static void RomanToInt(string pathname)
    {
    }
    
    public static string HanoiTowers(int n)
        {
            if (n < 0) // n nega veh teh jeh 0 to vadda
                throw new ArgumentException(""); // arg trhw kita 
            if (n == 0) // n jeh equal veh 
                return " "; // rt it 

            string ls = ""; // ethe string ls kita 
            fuddi(n, 'A', 'C', 'B', ref ls);
            return ls; // rt it 
        }

        private static void fuddi(int a, char put, char jiv, char po, ref string rlt)
        {
            if (a == 1) // ethe main a nu equal kita 
            { rlt += $"Move disk from tower {put} to tower {jiv}\n"; // rlt vekhya teh mov kita 
            }
            else
            {
                fuddi(a - 1, put, po, jiv, ref rlt); // nahi teh hor kite mov kita 
                rlt += $"Move disk from tower {put} to tower {jiv}\n"; // rlt mv ktia 
                fuddi(a - 1, po, jiv, put, ref rlt); // nahi teh hor mv kita 
            }
        }
    



}