﻿namespace TravelInEgyptix.Proficiencies;

public class Imagination
{
    // convert fun 
    public static string Convert(int number, int b)
    {
        if (b < 2 || b > 36) throw new ArgumentException(""); // ethe main throw argt kita 
        if (number == 0) return "0"; // ethe main if number karke rt it 0 kita 
        string t = ""; // fir main string kita 
        bool isNegative = number < 0;
        int m = number; // ethe main int nmber kita 
        if (isNegative) // ethe if kita 
        {
            m = -m;
        }

        while (m > 0)
        {
            int e = m % b;
            m /= b;
            t = (e >= 10) ? (char)(e - 10 + 'A') + t : (char)(e + '0') + t; // ethe while kita 
        }

        if (isNegative) t = "-" + t; // ethe main if 
        return t; // rt it t
    }
    // atox fun
    public static string AtoX(string pathname, int b)
    {
        try
        { if (b < 2 || b > 36) throw new ArgumentException(""); // ethe main throw argt kita 

            string ls = ""; using (StreamReader d = new StreamReader(pathname)) // ethe main string use kita 
            {
                int ti; while ((ti = d.Read()) != -1) ls += (char)ti;  // ethe main int use kita 
            } ls = ls.Trim(); if (string.IsNullOrEmpty(ls) || !MPT(ls)) //  main vkehya ki string is null of not 
                throw new ArgumentException(""); // the main throw argt kita 

            int mv = int.Parse(ls); // ethe main int mv kita 
            return rtc(mv, b); // rtc kita 
        }
        catch (Exception z)
        {
            throw new ArgumentException(" " + z.Message); // fir trhw arg kita 
        }
    }
    // fun mpt 
    private static bool MPT (string pl)
    {
        foreach (char o in pl) // ethe main forech kita 
            if (!char.IsDigit(o)) return false; // ethe main rt fsl 
        return true; // ethe rt it 
    }

    // fun rtc 
    private static string rtc(int j, int t)
    { 
        const string digits = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"; // ethe main const string kita 
        if (j == 0) return "0";

        string p = ""; while (j > 0) // ethe main string teh fir while kita 
        { p = digits[j % t] + p; j /= t;
        }
        return p; // rt it 
    }
}








