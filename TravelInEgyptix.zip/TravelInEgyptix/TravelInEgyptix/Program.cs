﻿using TravelInEgyptix.Fundamentals;
using TravelInEgyptix.Proficiencies;

/*long q1 = ArrivalInEgyptix.Quatrobonnaccius(0);    // q1 == 0
long q2 = ArrivalInEgyptix.Quatrobonnaccius(2);    // q2 == 1
long q3 = ArrivalInEgyptix.Quatrobonnaccius(24);   // q3 == 2033628
long q4 = ArrivalInEgyptix.Quatrobonnaccius(64);   // q4 == 1,1743946E+09
Console.WriteLine(q1);
Console.WriteLine(q2);
Console.WriteLine(q3);
Console.WriteLine(q4);

// Les ... symbolisent les nombres décimaux ignorés par la testsuite.
double p1 = ArrivalInEgyptix.ArchimedusNumber(0);   // p1 == 4.0
double p2 = ArrivalInEgyptix.ArchimedusNumber(1);   // p2 == 2.6666 ...
double p3 = ArrivalInEgyptix.ArchimedusNumber(15);  // p3 == 3,0791 ...
double p4 = ArrivalInEgyptix.ArchimedusNumber(256); // p4 == 3,1454 ... */

// Les "#.00" sont juste un moyen d'afficher un nombre spécifique de chiffres après la virgule
/*Console.WriteLine(p1.ToString("#."));
Console.WriteLine(p2.ToString("#.0"));
Console.WriteLine(p3.ToString("#.000"));
Console.WriteLine(p4.ToString("#.00000"));

int f1 = ArrivalInEgyptix.Atoi("Example1");   // f1 == 157
int f2 = ArrivalInEgyptix.Atoi("Example2");   // f2 == -9083897

Console.WriteLine(f1.ToString());
Console.WriteLine(f2.ToString()); */

/*string s1 = SOSEgyptians.CleoCode("Cleopatre", 2);          // s1 == "Gpistexvi"
string s2 = SOSEgyptians.CleoCode("", 20);                  // s2 == ""
string s3 = SOSEgyptians.CleoCode("Cleopatre", 0);          // s3 == "Cleopatre"
string s4 = SOSEgyptians.CleoCode("Astérix !", 3);          // s4 == "Gyzéxod !"
string s5 = SOSEgyptians.CleoCode("Gaulish Village", 30);   // s5 == "Oictqap Dqttiom"
string s6 = SOSEgyptians.CleoCode("Ykza za Cajet", 2);      // s6 == "Code de Genix"
Console.WriteLine(s1);
Console.WriteLine(s2);
Console.WriteLine(s3);
Console.WriteLine(s4);
Console.WriteLine(s5);
Console.WriteLine(s6);

int f2 = SOSEgyptians.RomanFormations('s', 5);      // f2 == 5
int f3 = SOSEgyptians.RomanFormations('t', 1024);   // f3 == 10240
int f4 = SOSEgyptians.RomanFormations('e', 1);      // f4 == 1
int f5 = SOSEgyptians.RomanFormations('e', 6);      // f5 == 36
int f6 = SOSEgyptians.RomanFormations('c', 255);    // f6 == 195840
Console.WriteLine(f2);
Console.WriteLine(f3);
Console.WriteLine(f4);
Console.WriteLine(f5);
Console.WriteLine(f6);


SOSEgyptians.Pyramids(3, 'o', "path_to_file");*/



// Les ... symbolisent les nombres décimaux ignorés par la testsuite.
/*double f1 = Calculator.Calculate('-', 8, -4);       // f1 == 12
double f2 = Calculator.Calculate('e', 0, 55.742);   // f2 == 1
double f3 = Calculator.Calculate('e', 0, -999);     // f3 == 1
double f4 = Calculator.Calculate('l', 8, -4);       // f4 == 2,0794...

Console.WriteLine(f1);
Console.WriteLine(f2);
Console.WriteLine(f3);
Console.WriteLine(f4);*/

/*bool m1 = EscapeJail.MovingCat("zzdd", 0, 0, 2, 2);          // m1 == true
bool m2 = EscapeJail.MovingCat("zsqzdzdddqz", 0, 0, 3, 2);   // m2 == false
Console.WriteLine(m1);
Console.WriteLine(m2);*/

/*string conv = Imagination.Convert(95, 16);
Console.WriteLine(conv);
string conv2 = Imagination.Convert(9999, 2);
Console.WriteLine(conv2);*/

/*string moves = LastWishes.HanoiTowers(3);
Console.WriteLine(moves);*/

/*string number = Imagination.AtoX("Example1", 2);     // number == 10011101
string number2 = Imagination.AtoX("Example1", 16);   // number == 9D
Console.WriteLine(number);
Console.WriteLine(number2);
*/